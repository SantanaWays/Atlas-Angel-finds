ATLAS ANGEL FINDS — FREE LAUNCH KIT
===================================

WHAT'S INCLUDED
- index.html: redesigned mobile-friendly home page
- styles.css and script.js: shared design and category finder
- about.html, contact.html, privacy.html, terms.html, affiliate-disclosure.html
- Three original starter buying guides
- robots.txt and sitemap.xml templates
- LAUNCH-CHECKLIST.txt

IMPORTANT LIMITS
- This is a static website package. It has not been published online.
- Search is a keyword/category demo, not a connected AI model.
- Marketplace links are ordinary search links, not affiliate-tracked.
- Advertising boxes are placeholders, not live ads.
- Affiliate/ad networks must approve your own account and website before tracking or payouts.
- Privacy/terms are starter templates, not legal advice; customize them for the actual services used.
- Before launch, replace the placeholder contact email in contact.js and review all policy pages.

FREE HOSTING FROM AN IPHONE (GITHUB PAGES)
1. Create/sign into GitHub: https://github.com/signup
2. Create a NEW public repository named atlas-angel-finds:
   https://github.com/new
3. Extract the ZIP on your phone if needed. Upload all files from this folder to the ROOT of the repository (not the folder as a nested directory).
4. Commit the upload.
5. In the repository open Settings > Pages.
6. Under Build and deployment, choose Deploy from a branch.
7. Choose branch main and folder /(root), then Save.
8. Wait a few minutes and open:
   https://YOUR-GITHUB-USERNAME.github.io/atlas-angel-finds/
   Replace YOUR-GITHUB-USERNAME with your GitHub username.
9. If the site doesn't load, confirm index.html is in the repository root and Pages deployment completed.

CONTACT EMAIL
Open contact.js and replace:
REPLACE-WITH-YOUR-EMAIL@example.com
with an email address you control. The contact form opens an email draft; it does not store or send messages on a server.

AFFILIATE SETUP
- eBay Partner Network: https://partnernetwork.ebay.com/
- Amazon Associates: https://affiliate-program.amazon.com/
After approval, generate tracking links in each program and replace the ordinary links in index.html. Do not claim the existing links earn commissions.

ADVERTISING SETUP
- Google AdSense: https://adsense.google.com/start/
Publish original useful content, add a real contact method, review policies, and apply. Approval is not guaranteed. Only add the official ad code after approval.

REAL AI
A real AI product recommender requires a model API plus a secure backend or serverless function. Never put a private API key in index.html, script.js, or a public repository. Start with the free keyword finder; connect an AI service only after checking current pricing and free-tier limits.

OFFICIAL HELP
GitHub Pages setup: https://docs.github.com/en/pages/getting-started-with-github-pages/creating-a-github-pages-site
